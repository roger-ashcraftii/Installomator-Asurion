
wwdcformac)
   #this label looks like software/site is gone
   name="WWDC"
   type="zip"
   downloadURL="https://cdn.wwdc.io/WWDC_latest.zip"
   expectedTeamID="8C7439RJLG"
   ;;
