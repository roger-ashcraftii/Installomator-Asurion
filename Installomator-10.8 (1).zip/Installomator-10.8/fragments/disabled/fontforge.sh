
fontforge)
   # FontForge Not signed
   # credit: Søren Theilgaard (@theilgaard)
   name="FontForge"
   type="dmg"
   downloadURL=$(downloadURLFromGit fontforge fontforge)
   appNewVersion=$(versionFromGit fontforge fontforge)
   expectedTeamID=""
   ;;
