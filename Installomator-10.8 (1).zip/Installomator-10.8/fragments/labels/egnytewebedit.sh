egnytewebedit)
    name="EgnyteWebEdit"
    type="pkg"
    downloadURL="https://egnyte-cdn.egnyte.com/webedit/mac/en-us/latest/EgnyteWebEdit.pkg"
    expectedTeamID="FELUD555VC"
    appName="Egnyte WebEdit.app"
    blockingProcesses=( NONE )
    ;;
    
