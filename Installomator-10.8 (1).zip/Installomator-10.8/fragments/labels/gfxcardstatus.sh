gfxcardstatus)
    name="gfxCardStatus"
    type="zip"
    downloadURL="$(downloadURLFromGit codykrieger gfxCardStatus)"
    appNewVersion="$(versionFromGit codykrieger gfxCardStatus)"
    expectedTeamID="LF22FTQC25"
    ;;
