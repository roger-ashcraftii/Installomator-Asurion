jamfcheck)
    name="jamfcheck"
    type="dmg"
    downloadURL="$(downloadURLFromGit txhaflaire JamfCheck)"
    appNewVersion="$(versionFromGit txhaflaire JamfCheck)"
    expectedTeamID="CLQKFNPCCP"
    ;;
