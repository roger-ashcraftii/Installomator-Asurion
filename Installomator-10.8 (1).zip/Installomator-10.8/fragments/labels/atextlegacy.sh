atextlegacy)
     # credit: Gabe Marchan (gabemarchan.com - @darklink87)
     name="aText"
     type="dmg"
     downloadURL="https://trankynam.com/atext/downloads/aTextLegacy.dmg"
     expectedTeamID="KHEMQ2FD9E"
     ;;
