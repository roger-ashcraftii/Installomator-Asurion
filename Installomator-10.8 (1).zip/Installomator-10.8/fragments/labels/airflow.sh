airflow)
    name="Air"
    type="dmg"
    downloadURL="$(downloadURLFromGit AirLabsTeam desktop-releases)"
    appNewVersion="$(versionFromGit AirLabsTeam desktop-releases)"
    expectedTeamID="8RBYE8TY7T"
    ;;
