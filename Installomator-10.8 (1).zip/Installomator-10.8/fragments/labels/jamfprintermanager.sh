jamfprintermanager)
    name="Jamf Printer Manager"
    type="zip"
    downloadURL="$(downloadURLFromGit jamf jamf-printer-manager)"
    appNewVersion="$(versionFromGit jamf jamf-printer-manager)"
    expectedTeamID="483DWKW443"
    ;;
