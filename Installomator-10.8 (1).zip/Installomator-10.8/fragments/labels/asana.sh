asana)
    name="Asana"
    type="dmg"
    downloadURL="https://desktop-downloads.asana.com/darwin_universal/prod/latest/Asana.dmg"
    expectedTeamID="A679L395M8"
    ;;
