escrowbuddy)
    name="Escrow Buddy"
    type="pkg"
    archiveName="Escrow.Buddy-[0-9.]*.pkg"
    packageID="com.netflix.Escrow-Buddy"
    appNewVersion=$(versionFromGit macadmins escrow-buddy )
    downloadURL=$(downloadURLFromGit macadmins escrow-buddy )
    expectedTeamID="T4SK8ZXCXG"
    ;;
