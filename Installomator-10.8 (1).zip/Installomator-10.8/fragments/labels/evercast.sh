evercast)
    name="Evercast"
    type="pkg"
    downloadURL="https://s3.amazonaws.com/files.evercast.us/Evercast.pkg"
    expectedTeamID="H2J9VR2HM2"
    ;;
