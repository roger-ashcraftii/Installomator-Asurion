iina)
    name="IINA"
    type="dmg"
    downloadURL=$(downloadURLFromGit iina iina )
    appNewVersion=$(versionFromGit iina iina )
    expectedTeamID="67CQ77V27R"
    ;;
