boxdrive)
    name="Box"
    type="pkg"
    downloadURL="https://e3.boxcdn.net/desktop/releases/mac/BoxDrive.pkg"
    expectedTeamID="M683GB7CPW"
    ;;
