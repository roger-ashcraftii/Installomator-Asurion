homebrew)
    name="Homebrew"
    type="pkg"
    packageID="sh.brew.homebrew"
    downloadURL="$(downloadURLFromGit Homebrew brew)"
    appNewVersion="$(versionFromGit Homebrew brew)"
    expectedTeamID="927JGANW46"
    archiveName="Homebrew.pkg"
    ;;
