aftermath)
    name="Aftermath"
    type="pkg"
    packageID="com.jamf.aftermath"
    downloadURL="$(downloadURLFromGit jamf aftermath)"
    appNewVersion="$(versionFromGit jamf aftermath)"
    expectedTeamID="C793NB2B2B"
    ;;
