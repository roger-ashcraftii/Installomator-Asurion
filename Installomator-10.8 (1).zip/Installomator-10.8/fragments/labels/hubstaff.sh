hubstaff)
    name="Hubstaff"
    type="dmg"
    downloadURL="https://app.hubstaff.com/download/osx"
    appNewVersion=""
    expectedTeamID="24BCJT3JW2"
    ;;
