geneiousprime)
    name="Geneious Prime"
    type="dmg"
    downloadURL="https://assets.geneious.com/installers/geneious/release/latest/Geneious_Prime_mac64_with_jre.dmg"
    appNewVersion=""
    expectedTeamID="3BTDDQD3L6"
    ;;
