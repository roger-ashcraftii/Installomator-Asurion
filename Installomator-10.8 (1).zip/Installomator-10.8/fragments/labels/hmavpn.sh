hmavpn)
name="HMA-VPN"
type="pkgInDmg"
packageID="com.privax.osx.provpn"
downloadURL="https://s-mac-sl.avcdn.net/macosx/privax/HMA-VPN.dmg"
appNewVersion=""
expectedTeamID="96HLSU34RN"
;;
