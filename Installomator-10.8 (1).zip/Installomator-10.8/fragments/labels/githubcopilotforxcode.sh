githubcopilotforxcode)
    name="GitHub Copilot for Xcode"
    type="dmg"
    downloadURL="$(downloadURLFromGit github CopilotForXcode)"
    appNewVersion="$(versionFromGit github CopilotForXcode)"
    expectedTeamID="VEKTX9H2N7"
    blockingProcesses=( "GitHub Copilot for Xcode" "GitHub Copilot for Xcode Extension" "Copilot" )
    ;;
