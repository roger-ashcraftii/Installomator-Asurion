airtable)
    name="Airtable"
    type="dmg"
    downloadURL="https://static.airtable.com/download/AirtableInstaller.dmg"
    expectedTeamID="E22RZMX62E"
    ;;
