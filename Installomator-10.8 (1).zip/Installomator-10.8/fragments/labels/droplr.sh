droplr)
    name="Droplr"
    type="dmg"
    downloadURL="$(downloadURLFromGit Droplr droplr-desktop-releases)"
    appNewVersion="$(versionFromGit Droplr droplr-desktop-releases)"
    expectedTeamID="MZ25PHMY7Y"
    ;;
