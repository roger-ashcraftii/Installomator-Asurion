cmake)
    name="CMake"
    type="dmg"
    downloadURL=$(downloadURLFromGit Kitware CMake)
    appNewVersion=$(versionFromGit Kitware CMake)
    expectedTeamID="W38PE5Y733"
    ;;
