boop)
    name="Boop"
    type="zip"
    downloadURL=$(downloadURLFromGit IvanMathy Boop)
    appNewVersion=$(versionFromGit IvanMathy Boop)
    expectedTeamID="RLZ8XBTX7G"
    ;;
