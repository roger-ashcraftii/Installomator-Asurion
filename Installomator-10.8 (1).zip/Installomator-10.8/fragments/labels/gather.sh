gather|\
gathertown)
    name="Gather"
    type="dmg"
    appNewVersion="$(versionFromGit gathertown gather-town-desktop-releases)"
    downloadURL="$(downloadURLFromGit gathertown gather-town-desktop-releases)"
    archiveName="Gather-${appNewVersion}-universal.dmg"
    expectedTeamID="69MCJ5CRDW"
    ;;

