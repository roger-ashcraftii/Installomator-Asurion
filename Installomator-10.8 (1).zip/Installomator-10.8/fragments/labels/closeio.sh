closeio)
    name="Close.io"
    type="dmg"
    downloadURL=$(downloadURLFromGit closeio closeio-desktop-releases)
    appNewVersion=$(versionFromGit closeio closeio-desktop-releases)
    expectedTeamID="WTNQ6773UC"
    ;;
