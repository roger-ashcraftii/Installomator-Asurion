alephone)
    name="Aleph One"
    type="dmg"
    downloadURL=$(downloadURLFromGit Aleph-One-Marathon alephone)
    appNewVersion=$(versionFromGit Aleph-One-Marathon alephone)
    expectedTeamID="E8K89CXZE7"
    ;;
