fellow)
    name="Fellow"
    type="dmg"
    downloadURL="https://cdn.fellow.app/desktop/1.3.11/darwin/stable/universal/Fellow-1.3.11-universal.dmg"
    appNewVersion=""
    expectedTeamID="2NF46HY8D8"
    ;;
