gotowebinar)
    name="GoTo"
    type="dmg"
    downloadURL="https://goto-desktop.goto.com/GoTo-arm64.dmg"
    appNewVersion=""
    expectedTeamID="GFNFVT632V"
    ;;
