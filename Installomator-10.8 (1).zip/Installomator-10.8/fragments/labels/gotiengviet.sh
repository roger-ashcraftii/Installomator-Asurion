gotiengviet)
    name="GoTiengViet"
    type="dmg"
    downloadURL="https://www.trankynam.com/gotv/downloads/GoTiengViet.dmg"
    appNewVersion=""
    expectedTeamID="KHEMQ2FD9E"
    ;;
