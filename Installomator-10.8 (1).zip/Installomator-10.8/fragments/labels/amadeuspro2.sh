amadeuspro2)
	# A powerful audio editing tool for macOS, offering multi-track editing, batch processing, and a variety of sound analysis feature
    name="Amadeus Pro"
    type="zip"
    downloadURL="https://s3.amazonaws.com/AmadeusPro2/AmadeusPro.zip"
    expectedTeamID="FWDH9W45C2"
    ;;
