basictex)
    # Small LaTeX alternative to mactex
    name="BasicTeX"
    type="pkg"
    downloadURL="https://mirror.ctan.org/systems/mac/mactex/BasicTeX.pkg"
    expectedTeamID="RBGCY5RJWM"
    ;;
