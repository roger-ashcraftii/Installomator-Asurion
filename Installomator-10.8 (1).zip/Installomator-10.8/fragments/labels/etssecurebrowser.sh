etssecurebrowser)
    name="ETS Secure Browser"
    type="dmg"
    downloadURL="https://ibtprod-rp.ets.org/SoftwareDistribution/rp/PROD/mac/ETS-RP-PROD.dmg"
    versionKey="CFBundleShortVersionString"
    expectedTeamID="WGC236CZU9"
    ;;
