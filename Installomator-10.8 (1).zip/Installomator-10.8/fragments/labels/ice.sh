ice)
	# A versatile macOS menu bar management tool that allows users to hide, show, and rearrange menu bar items
    name="Ice"
    type="zip"
    downloadURL="$(downloadURLFromGit jordanbaird Ice)"
    appNewVersion="$(versionFromGit jordanbaird Ice)"
    expectedTeamID="K2ATHQPJDP"
    ;;
