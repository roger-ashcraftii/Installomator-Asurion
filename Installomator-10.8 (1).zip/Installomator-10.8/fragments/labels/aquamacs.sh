aquamacs)
    name="Aquamacs"
    type="dmg"
    downloadURL="$(downloadURLFromGit aquamacs-emacs aquamacs-emacs)"
    appNewVersion="$(versionFromGit aquamacs-emacs aquamacs-emacs)"
    expectedTeamID="DTBC5BX3L9"
    ;;
