hot)
    name="Hot"
    type="zip"
    downloadURL="$(downloadURLFromGit macmade Hot)"
    appNewVersion="$(versionFromGit macmade Hot)"
    expectedTeamID="326Y53CJMD"
    ;;
