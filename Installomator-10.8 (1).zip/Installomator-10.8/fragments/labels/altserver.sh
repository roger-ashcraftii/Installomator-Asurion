altserver)
    name="AltServer"
    type="zip"
    downloadURL="https://cdn.altstore.io/file/altstore/altserver.zip"
    appNewVersion=""
    expectedTeamID="6XVY5G3U44"
    ;;
