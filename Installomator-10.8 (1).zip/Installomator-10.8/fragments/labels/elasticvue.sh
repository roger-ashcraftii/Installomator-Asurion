elasticvue)
    name="elasticvue"
    type="dmg"
    downloadURL="$(downloadURLFromGit cars10 elasticvue)"
    appNewVersion="$(versionFromGit cars10 elasticvue)"
    expectedTeamID="9L4YGY6JVY"
    ;;
