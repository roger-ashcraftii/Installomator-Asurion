automounter)
    name="AutoMounter"
    type="dmg"
    downloadURL="https://www.pixeleyes.co.nz/automounter/AutoMounter.dmg"
    appNewVersion="$( curl -fs https://www.pixeleyes.co.nz/automounter/version )"
    versionKey="CFBundleShortVersionString"
    expectedTeamID="UKWABN4MGL"
    ;;
