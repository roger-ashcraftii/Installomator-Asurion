depnotify)
    name="DEPNotify"
    type="pkg"
    downloadURL="https://files.jamfconnect.com/DEPNotify.pkg"
    expectedTeamID="VRPY9KHGX6"
    ;;
