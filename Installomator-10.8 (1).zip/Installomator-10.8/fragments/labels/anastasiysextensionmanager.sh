anastasiysextensionmanager)
    name="ExtensionManager"
    type="zip"
    downloadURL="https://f000.backblazeb2.com/file/anastasiy-downloads/EM/ExtensionManager.zip"
    expectedTeamID="D3SBBNFWTC"
    ;;
