eul)
    name="eul"
    type="zip"
    downloadURL="$(downloadURLFromGit gao-sun eul)"
    appNewVersion="$(versionFromGit gao-sun eul)"
    expectedTeamID="M8G2RFZVFV"
    ;;
