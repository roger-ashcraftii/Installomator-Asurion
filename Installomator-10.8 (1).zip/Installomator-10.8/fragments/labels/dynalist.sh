dynalist)
    name="Dynalist"
    type="dmg"
    downloadURL="https://dynalist.io/standalone/download?file=Dynalist.dmg"
    appNewVersion=""
    expectedTeamID="6JSW4SJWN9"
    ;;
