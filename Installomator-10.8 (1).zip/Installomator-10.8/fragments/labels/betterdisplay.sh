betterdisplay)
    name="BetterDisplay"
    type="dmg"
    downloadURL=$(downloadURLFromGit waydabber BetterDisplay)
    appNewVersion=$(versionFromGit waydabber BetterDisplay)
    expectedTeamID="299YSU96J7"
    ;;
