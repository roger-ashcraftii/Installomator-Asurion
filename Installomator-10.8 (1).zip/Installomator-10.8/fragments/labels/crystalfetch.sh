crystalfetch)
	name="CrystalFetch"
	type="dmg"
    downloadURL=$(downloadURLFromGit TuringSoftware CrystalFetch)
    appNewVersion=$(versionFromGit TuringSoftware CrystalFetch)
    expectedTeamID="WDNLXAD4W8"
    ;;
