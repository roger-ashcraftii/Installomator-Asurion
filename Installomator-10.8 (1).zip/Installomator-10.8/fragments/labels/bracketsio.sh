adobebrackets|\
bracketsio)
    name="Brackets"
    type="dmg"
    downloadURL=$(downloadURLFromGit brackets-cont brackets )
    appNewVersion=$(versionFromGit brackets-cont brackets )
    expectedTeamID="JQ525L2MZD"
    ;;
