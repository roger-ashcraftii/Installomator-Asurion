dangerzone)
    name="Dangerzone"
    type="dmg"
    downloadURL="$(downloadURLFromGit freedomofpress dangerzone)"
    appNewVersion="$(versionFromGit freedomofpress dangerzone)"
    expectedTeamID="N9B95FDWH4"
    ;;
