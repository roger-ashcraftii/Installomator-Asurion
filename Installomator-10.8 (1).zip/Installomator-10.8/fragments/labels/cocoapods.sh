cocoapods)
    name="CocoaPods"
    type="bz2"
    downloadURL="$(downloadURLFromGit CocoaPods CocoaPods-app)"
    appNewVersion="$(versionFromGit CocoaPods CocoaPods-app)"
    expectedTeamID="AX2Q2BH2XR"
    ;;
