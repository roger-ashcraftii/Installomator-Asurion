alttab)
    name="AltTab"
    type="zip"
    downloadURL=$(downloadURLFromGit lwouis alt-tab-macos)
    appNewVersion=$(versionFromGit lwouis alt-tab-macos)
    expectedTeamID="QXD7GW8FHY"
    ;;
