bambustudio)
    name="BambuStudio"
    type="dmg"
    downloadURL=$(downloadURLFromGit "bambulab" "BambuStudio")
    appNewVersion=$(versionFromGit "bambulab" "BambuStudio")
    expectedTeamID="T3UBR9Y3B2"
    ;;
