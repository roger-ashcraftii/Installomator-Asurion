diskspace)
    name="diskspace"
    type="pkg"
    packageID="com.scriptingosx.diskspace"
    downloadURL="$(downloadURLFromGit scriptingosx diskspace)"
    appNewVersion="$(versionFromGit scriptingosx diskspace)"
    expectedTeamID="JME5BW3F3R"
    ;;
