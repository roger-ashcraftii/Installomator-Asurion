backgrounds)
    name="Backgrounds"
    type="zip"
    downloadURL="$(downloadURLFromGit SAP backgrounds)"
    appNewVersion="$(versionFromGit SAP backgrounds)"
    expectedTeamID="7R5ZEU67FQ"
    ;;

