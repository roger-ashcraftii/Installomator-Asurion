icons)
    name="Icons"
    type="pkg"
    downloadURL=$(downloadURLFromGit SAP macOS-icon-generator )
    appNewVersion=$(versionFromGit SAP macOS-icon-generator )
    expectedTeamID="7R5ZEU67FQ"
    ;;
