clipy)
	name="Clipy"
	type="dmg"
    downloadURL=$(downloadURLFromGit Clipy Clipy)
    appNewVersion=$(versionFromGit Clipy Clipy)
    expectedTeamID="BBCHAJ584H"
    ;;
