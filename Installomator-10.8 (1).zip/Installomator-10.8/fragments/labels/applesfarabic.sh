applesfarabic)
    name="San Francisco Arabic"
    type="pkgInDmg"
    downloadURL="https://devimages-cdn.apple.com/design/resources/download/SF-Arabic.dmg"
    packageID="com.apple.pkg.SFArabicFonts"
    expectedTeamID="Software Update"
    ;;
