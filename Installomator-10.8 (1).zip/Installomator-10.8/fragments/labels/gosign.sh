gosign)
    name="GoSign-Desktop"
    type="dmg"
    downloadURL="https://rinnovofirma.infocert.it/gosign/download/darwin/latest/"
    expectedTeamID="QC25859FX9"
    ;;
