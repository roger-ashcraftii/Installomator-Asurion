chromeremotedesktop)
    name="chromeremotedesktop"
    type="pkgInDmg"
    packageID="com.google.pkg.ChromeRemoteDesktopHost"
    downloadURL="https://dl.google.com/chrome-remote-desktop/chromeremotedesktop.dmg"
    appNewVersion=""
    expectedTeamID="EQHXZ8M8AV"
    ;;
