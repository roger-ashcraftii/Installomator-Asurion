calibriteprofiler)
    name="calibrite PROFILER"
    type="dmg"
    downloadURL="$(downloadURLFromGit LUMESCA calibrite-profiler-releases)"
    appNewVersion="$(versionFromGit LUMESCA calibrite-profiler-releases)"
    expectedTeamID="5C392763F5"
    ;;
