backgroundmusic)
    name="BackgroundMusic"
    type="pkg"
    packageID="com.bearisdriving.BGM"
    downloadURL="$(downloadURLFromGit kyleneideck BackgroundMusic)"
    appNewVersion="$(versionFromGit kyleneideck BackgroundMusic)"
    expectedTeamID="PR7PXC66S5"
    ;;
