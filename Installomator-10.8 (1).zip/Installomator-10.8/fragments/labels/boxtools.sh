boxtools)
    name="Box Tools"
    type="pkg"
    downloadURL="https://box-installers.s3.amazonaws.com/boxedit/mac/currentrelease/BoxToolsInstaller.pkg"
    packageID="com.box.boxtools.installer.boxedit"
    expectedTeamID="M683GB7CPW"
    ;;
