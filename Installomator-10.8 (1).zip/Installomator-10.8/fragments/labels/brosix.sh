brosix)
    name="Brosix"
    type="pkg"
    downloadURL="https://www.brosix.com/downloads/builds/official/Brosix.pkg"
    appNewVersion=""
    expectedTeamID="TA6P23NW8H"
    ;;
