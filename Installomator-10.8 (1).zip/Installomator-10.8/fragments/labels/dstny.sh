dstny)
    name="Dstny"
    type="dmg"
    downloadURL="https://soft.dstny.se/dstny_mac.dmg"
    # appNewVersion=""
    expectedTeamID="5RLWBLKGL2"
    versionKey="CFBundleVersion"
    ;;
