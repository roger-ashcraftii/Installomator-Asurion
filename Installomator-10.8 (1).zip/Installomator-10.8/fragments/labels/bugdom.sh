bugdom)
    name="Bugdom"
    type="dmg"
    downloadURL=$(downloadURLFromGit jorio Bugdom)
    appNewVersion=$(versionFromGit jorio Bugdom)
    expectedTeamID="RVNL7XC27G"
    ;;
