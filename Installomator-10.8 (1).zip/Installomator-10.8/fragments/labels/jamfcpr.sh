jamfcpr)
    name="jamfcpr"
    type="zip"
    downloadURL="$(downloadURLFromGit BIG-RAT jamfcpr)"
    appNewVersion="$(versionFromGit BIG-RAT jamfcpr)"
    expectedTeamID="PS2F6S478M"
    ;;
